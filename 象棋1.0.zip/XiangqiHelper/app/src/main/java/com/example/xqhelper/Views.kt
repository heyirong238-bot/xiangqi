package com.example.xqhelper

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** 全屏透明层，画推荐走法的箭头（不拦截触摸） */
class ArrowView(c: Context) : View(c) {
    private var a: FloatArray? = null
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00C853.toInt(); strokeWidth = 14f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00C853.toInt(); style = Paint.Style.FILL }

    fun set(ax: Float, ay: Float, bx: Float, by: Float) { a = floatArrayOf(ax, ay, bx, by); invalidate() }
    fun clear() { a = null; invalidate() }

    override fun onDraw(c: Canvas) {
        val v = a ?: return
        val loc = IntArray(2); getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val ang = atan2(v[3] - v[1], v[2] - v[0]); val ux = cos(ang); val uy = sin(ang); val hd = 46f
        c.drawLine(v[0], v[1], v[2] - ux * hd * 0.8f, v[3] - uy * hd * 0.8f, line)
        val p = Path().apply {
            moveTo(v[2], v[3])
            lineTo(v[2] - ux * hd - uy * hd * 0.5f, v[3] - uy * hd + ux * hd * 0.5f)
            lineTo(v[2] - ux * hd + uy * hd * 0.5f, v[3] - uy * hd - ux * hd * 0.5f)
            close()
        }
        c.drawPath(p, fill)
        c.drawCircle(v[0], v[1], 26f, line)
    }
}

/** 校准层：拖动两个黄色圆圈，使红线网格对准棋盘的 9×10 个交叉点 */
class CalibView(
    c: Context, var x0: Float, var y0: Float, var x1: Float, var y1: Float,
    var flipped: Boolean, private val done: (Boolean) -> Unit
) : View(c) {
    private val grid = Paint().apply { color = 0xAAFF1744.toInt(); strokeWidth = 3f }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFEB3B.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 44f; textAlign = Paint.Align.CENTER }
    private val bg = Paint().apply { color = 0xEE202020.toInt() }
    private var drag = -1; private var lx = 0f; private var ly = 0f

    private fun btn(i: Int): RectF { val w = width / 3f; return RectF(i * w + 10, height - 230f, (i + 1) * w - 10, height - 100f) }

    override fun onDraw(c: Canvas) {
        for (i in 0..2) {
            val r = btn(i); c.drawRect(r, bg)
            val t = when (i) { 0 -> "确定"; 1 -> "取消"; else -> if (flipped) "我执黑" else "我执红" }
            c.drawText(t, r.centerX(), r.centerY() + 15, txt)
        }
        val loc = IntArray(2); getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        for (i in 0..8) { val x = x0 + i * (x1 - x0) / 8f; c.drawLine(x, y0, x, y1, grid) }
        for (j in 0..9) { val y = y0 + j * (y1 - y0) / 9f; c.drawLine(x0, y, x1, y, grid) }
        c.drawCircle(x0, y0, 60f, ring); c.drawCircle(x1, y1, 60f, ring)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                for (i in 0..2) if (btn(i).contains(e.x, e.y)) {
                    when (i) { 0 -> done(true); 1 -> done(false); else -> { flipped = !flipped; invalidate() } }
                    return true
                }
                val d0 = hypot(e.rawX - x0, e.rawY - y0); val d1 = hypot(e.rawX - x1, e.rawY - y1)
                drag = if (minOf(d0, d1) < 220f) (if (d0 < d1) 0 else 1) else -1
                lx = e.rawX; ly = e.rawY
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - lx; val dy = e.rawY - ly; lx = e.rawX; ly = e.rawY
                if (drag == 0) { x0 += dx; y0 += dy } else if (drag == 1) { x1 += dx; y1 += dy }
                invalidate()
            }
            MotionEvent.ACTION_UP -> drag = -1
        }
        return true
    }
}
