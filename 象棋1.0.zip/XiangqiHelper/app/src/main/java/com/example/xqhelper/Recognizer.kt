package com.example.xqhelper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlin.math.*

/**
 * 自动识别：用文字识别读出屏幕上的棋子字（帅仕相马车炮兵 / 将士象马车炮卒），
 * 用文字颜色分红黑，用棋子坐标自动算出棋盘格子，不需要任何学习步骤。
 */
class Recognizer(ctx: Context) {
    class Piece(val cx: Float, val cy: Float, val type: Char, val red: Boolean)
    class Result(val board: Array<CharArray>?, val msg: String)

    companion object {
        private val TYPES = mapOf(
            '帥' to 'K', '帅' to 'K', '將' to 'K', '将' to 'K', '仕' to 'A', '士' to 'A',
            '相' to 'B', '象' to 'B', '傌' to 'N', '馬' to 'N', '马' to 'N',
            '俥' to 'R', '車' to 'R', '车' to 'R', '炮' to 'C', '砲' to 'C', '兵' to 'P', '卒' to 'P')
        private const val RED = "帥仕相傌俥炮兵"
        private const val BLK = "將士象馬車砲卒"
        private const val ORDER = "KABNRCP"

        /** 棋盘 → FEN；将帅不是各一个就返回 null */
        fun toFen(b: Array<CharArray>, redToMove: Boolean): String? {
            val flat = b.flatMap { it.toList() }
            if (flat.count { it == 'K' } != 1 || flat.count { it == 'k' } != 1) return null
            val rows = b.joinToString("/") { r ->
                val sb = StringBuilder(); var n = 0
                for (c in r) { if (c == '.') n++ else { if (n > 0) { sb.append(n); n = 0 }; sb.append(c) } }
                if (n > 0) sb.append(n)
                sb.toString()
            }
            return "$rows ${if (redToMove) "w" else "b"} - - 0 1"
        }

        /** 两个签名之间有几个格子发生了明显变化 */
        fun sigDiff(a: IntArray, b: IntArray): Int {
            var n = 0
            for (k in 0 until 90) {
                val d = abs(a[k * 3] - b[k * 3]) + abs(a[k * 3 + 1] - b[k * 3 + 1]) + abs(a[k * 3 + 2] - b[k * 3 + 2])
                if (d > 60) n++
            }
            return n
        }

        /** 把识别结果画成文字棋盘，方便核对（上面是黑方） */
        fun pretty(b: Array<CharArray>): String = b.joinToString("\n") { r ->
            r.joinToString("") { c ->
                if (c == '.') "＋" else (if (c.isUpperCase()) RED else BLK)[ORDER.indexOf(c.uppercaseChar())].toString()
            }
        }
    }

    var x0 = 0f; var y0 = 0f; var x1 = 0f; var y1 = 0f
    var flipped = false          // 红方是否在屏幕上方（每次识别时自动判断）
    val calibrated: Boolean get() = x1 > x0 && y1 > y0

    private val prefs = ctx.getSharedPreferences("cfg", 0)
    private val ocr by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }

    init {
        x0 = prefs.getFloat("x0", 0f); y0 = prefs.getFloat("y0", 0f)
        x1 = prefs.getFloat("x1", 0f); y1 = prefs.getFloat("y1", 0f)
        flipped = prefs.getBoolean("flip", false)
    }

    fun setCalib(a: Float, b: Float, c: Float, d: Float, f: Boolean) {
        x0 = a; y0 = b; x1 = c; y1 = d; flipped = f
        prefs.edit().putFloat("x0", a).putFloat("y0", b).putFloat("x1", c).putFloat("y1", d).putBoolean("flip", f).apply()
    }

    /** 逻辑坐标（x 0-8 自左，y 0-9 自上，黑在上）→ 屏幕像素 */
    fun toScreen(x: Int, y: Int): Pair<Float, Float> {
        val c = if (flipped) 8 - x else x
        val r = if (flipped) 9 - y else y
        return Pair(x0 + c * (x1 - x0) / 8f, y0 + r * (y1 - y0) / 9f)
    }

    /** 很便宜的"棋盘指纹"：每格中心几个点的平均颜色，用来发现有人走了子 */
    fun signature(b: Bitmap): IntArray? {
        if (!calibrated) return null
        val cw = (x1 - x0) / 8f; val ch = (y1 - y0) / 9f
        val out = IntArray(90 * 3); var i = 0
        for (r in 0..9) for (c in 0..8) {
            var sr = 0; var sg = 0; var sb = 0
            for (dy in -1..1) for (dx in -1..1) {
                val px = (x0 + c * cw + dx * cw * 0.18f).toInt().coerceIn(0, b.width - 1)
                val py = (y0 + r * ch + dy * ch * 0.18f).toInt().coerceIn(0, b.height - 1)
                val p = b.getPixel(px, py)
                sr += Color.red(p); sg += Color.green(p); sb += Color.blue(p)
            }
            out[i++] = sr / 9; out[i++] = sg / 9; out[i++] = sb / 9
        }
        return out
    }

    // ---------- 文字识别 ----------
    private fun isRed(b: Bitmap, r: Rect): Boolean {
        val l = r.left.coerceIn(0, b.width - 1); val t = r.top.coerceIn(0, b.height - 1)
        val w = r.width().coerceIn(1, b.width - l); val h = r.height().coerceIn(1, b.height - t)
        val px = IntArray(w * h); b.getPixels(px, 0, w, l, t, w, h)
        var n = 0
        for (p in px) {
            val rr = Color.red(p); val g = Color.green(p); val bb = Color.blue(p)
            if (rr > 140 && rr - g > 60 && rr - bb > 60) n++
        }
        return n > px.size * 0.04
    }

    private fun scan(b: Bitmap, rotated: Boolean, w: Int, h: Int, out: MutableList<Piece>) {
        val text = Tasks.await(ocr.process(InputImage.fromBitmap(b, 0)))
        for (blk in text.textBlocks) for (ln in blk.lines) for (el in ln.elements) {
            val items = ArrayList<Pair<String, Rect?>>()
            if (el.symbols.isNotEmpty()) el.symbols.forEach { items.add(Pair(it.text, it.boundingBox)) }
            else items.add(Pair(el.text, el.boundingBox))
            for ((t, r) in items) {
                if (t.length != 1 || r == null) continue
                val ty = TYPES[t[0]] ?: continue
                var cx = r.exactCenterX(); var cy = r.exactCenterY()
                val red = isRed(b, r)
                if (rotated) { cx = w - cx; cy = h - cy }
                out.add(Piece(cx, cy, ty, red))
            }
        }
    }

    // ---------- 自动找棋盘格 ----------
    /** 在 [lo,hi] 里找让所有坐标最接近等间距点阵的间距，返回 [间距, 原点] */
    private fun fitAxis(v: List<Float>, lo: Float, hi: Float): FloatArray? {
        var bestD = 0f; var bestR = -1.0; var bestPh = 0.0
        var d = lo
        while (d <= hi) {
            var s = 0.0; var c = 0.0
            for (x in v) { val a = 2 * PI * x / d; s += sin(a); c += cos(a) }
            val r = hypot(s, c) / v.size
            if (r > bestR) { bestR = r; bestD = d; bestPh = atan2(s, c) }
            d += 0.5f
        }
        if (bestR < 0.8) return null
        return floatArrayOf(bestD, (bestPh / (2 * PI) * bestD).toFloat())
    }

    private fun autoGrid(ps: List<Piece>, sw: Float): FloatArray? {
        val fx = fitAxis(ps.map { it.cx }, sw * 0.07f, sw * 0.14f) ?: return null
        val fy = fitAxis(ps.map { it.cy }, sw * 0.07f, sw * 0.14f) ?: return null
        val good = ps.filter {
            val kx = (it.cx - fx[1]) / fx[0]; val ky = (it.cy - fy[1]) / fy[0]
            abs(kx - kx.roundToInt()) < 0.28f && abs(ky - ky.roundToInt()) < 0.28f
        }
        if (good.size < 8) return null
        val ix = good.map { ((it.cx - fx[1]) / fx[0]).roundToInt() }
        val iy = good.map { ((it.cy - fy[1]) / fy[0]).roundToInt() }
        if (ix.max() - ix.min() != 8 || iy.max() - iy.min() != 9) return null
        val gx = fx[1] + ix.min() * fx[0]; val gy = fy[1] + iy.min() * fy[0]
        return floatArrayOf(gx, gy, gx + 8 * fx[0], gy + 9 * fy[0])
    }

    private fun fits(v: Float, o: Float, cell: Float, maxIdx: Int): Boolean {
        val k = ((v - o) / cell).roundToInt()
        return k in 0..maxIdx && abs(v - o - k * cell) < cell * 0.3f
    }

    fun recognize(bmp: Bitmap): Result {
        val all = ArrayList<Piece>()
        scan(bmp, false, bmp.width, bmp.height, all)
        // 对方的字常常是倒着写的：把画面转 180° 再读一遍
        val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(180f) }, true)
        val extra = ArrayList<Piece>()
        scan(rot, true, bmp.width, bmp.height, extra)
        val tol = bmp.width * 0.04f
        for (p in extra) if (all.none { hypot(it.cx - p.cx, it.cy - p.cy) < tol }) all.add(p)
        if (all.size < 8) return Result(null, "只认出 ${all.size} 个棋子。请让棋盘完整显示在屏幕上，别被弹窗挡住")

        var ok = false
        if (calibrated) {
            val cw = (x1 - x0) / 8f; val ch = (y1 - y0) / 9f
            ok = all.count { fits(it.cx, x0, cw, 8) && fits(it.cy, y0, ch, 9) } >= all.size * 0.85
        }
        if (!ok) {
            val g = autoGrid(all, bmp.width.toFloat())
                ?: return Result(null, "认出 ${all.size} 个棋子，但定不出完整棋盘范围（残局常见）。请点「校准」手动对一次")
            setCalib(g[0], g[1], g[2], g[3], flipped)
        }

        val cw = (x1 - x0) / 8f; val ch = (y1 - y0) / 9f
        class Cell(val c: Int, val r: Int, val p: Piece)
        val cells = ArrayList<Cell>()
        for (p in all) {
            if (fits(p.cx, x0, cw, 8) && fits(p.cy, y0, ch, 9))
                cells.add(Cell(((p.cx - x0) / cw).roundToInt(), ((p.cy - y0) / ch).roundToInt(), p))
        }
        val rk = cells.firstOrNull { it.p.type == 'K' && it.p.red }
        val bk = cells.firstOrNull { it.p.type == 'K' && !it.p.red }
        if (rk == null || bk == null)
            return Result(null, "没找到${if (rk == null) "红方的帅" else "黑方的将"}（认出 ${cells.size} 个棋子），点「核对」看看")
        flipped = rk.r < bk.r          // 红方在上方 = 棋盘翻转
        val board = Array(10) { CharArray(9) { '.' } }
        for (c in cells) {
            val lx = if (flipped) 8 - c.c else c.c
            val ly = if (flipped) 9 - c.r else c.r
            if (board[ly][lx] == '.') board[ly][lx] = if (c.p.red) c.p.type else c.p.type.lowercaseChar()
        }
        return Result(board, "ok")
    }
}
