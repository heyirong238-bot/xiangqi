package com.example.xqhelper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private var askedNotif = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 120, 48, 48) }
        l.addView(TextView(this).apply {
            text = "象棋助手\n\n0. 先点「导入神经网络」，选择 pikafish.nnue（只需一次）\n1. 点下面的按钮，授予「悬浮窗」权限后回到本页再点一次\n" +
                "2. 允许屏幕录制（只用来截取棋盘，不保存）\n" +
                "3. 打开象棋游戏，在开局画面用悬浮窗：校准 → 学习 → 分析"
            textSize = 16f
        })
        l.addView(Button(this).apply {
            text = "导入神经网络（pikafish.nnue）"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 3)
            }
        })
        l.addView(Button(this).apply { text = "启动悬浮窗"; setOnClickListener { go() } })
        setContentView(l)
    }

    private fun importNnue(uri: android.net.Uri) {
        Toast.makeText(this, "正在导入，请稍等…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = try {
                contentResolver.openInputStream(uri)!!.use { i ->
                    File(filesDir, "pikafish.nnue").outputStream().use { o -> i.copyTo(o) } }
                true
            } catch (e: Exception) { false }
            runOnUiThread { Toast.makeText(this, if (ok) "导入完成" else "导入失败，请重试", Toast.LENGTH_LONG).show() }
        }.start()
    }

    private fun go() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askedNotif = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) = go()

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 3 && res == RESULT_OK && d?.data != null) { importNnue(d!!.data!!); return }
        if (rc == 1 && res == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", d))
            moveTaskToBack(true)
        }
    }
}
