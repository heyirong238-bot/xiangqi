package com.example.xqhelper

import android.content.Context
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.IOException

/** 通过 UCI 协议驱动皮卡鱼（libpikafish.so 实际是一个可执行文件） */
class Engine(private val ctx: Context) {
    data class Result(val move: String, val cp: Int?, val mate: Int?, val depth: Int)

    private var proc: Process? = null
    private var out: BufferedWriter? = null
    private var inp: BufferedReader? = null

    private fun send(s: String) { out!!.write(s + "\n"); out!!.flush() }
    private fun waitFor(p: String) {
        while (true) {
            val l = inp!!.readLine() ?: throw IOException("引擎已退出")
            if (l.startsWith(p)) return
        }
    }

    /** 返回 null 表示成功，否则返回错误说明 */
    @Synchronized fun start(): String? {
        if (proc != null) return null
        val exe = File(ctx.applicationInfo.nativeLibraryDir, "libpikafish.so")
        if (!exe.exists()) return "没有找到 libpikafish.so：请把安卓 arm64 版皮卡鱼放进 jniLibs/arm64-v8a 后重新编译"
        val nnue = File(ctx.filesDir, "pikafish.nnue")
        try {
            if (!nnue.exists() || nnue.length() == 0L) {
                ctx.assets.open("pikafish.nnue").use { i -> nnue.outputStream().use { o -> i.copyTo(o) } }
            }
        } catch (e: Exception) { nnue.delete(); return "还没导入神经网络：请回到 App 首页点「导入神经网络」选择 pikafish.nnue" }
        return try {
            proc = ProcessBuilder(exe.path).redirectErrorStream(true).start()
            out = proc!!.outputStream.bufferedWriter()
            inp = proc!!.inputStream.bufferedReader()
            send("uci"); waitFor("uciok")
            send("setoption name EvalFile value ${nnue.path}")
            send("setoption name Threads value ${Runtime.getRuntime().availableProcessors().coerceIn(1, 4)}")
            send("isready"); waitFor("readyok")
            null
        } catch (e: Exception) { stop(); "启动皮卡鱼失败：${e.message}" }
    }

    @Synchronized fun analyze(fen: String, ms: Int): Result {
        send("position fen $fen")
        send("go movetime $ms")
        var cp: Int? = null; var mate: Int? = null; var depth = 0
        while (true) {
            val l = inp!!.readLine() ?: throw IOException("引擎已退出")
            if (l.startsWith("info") && " score " in l) {
                val t = l.split(" ")
                val di = t.indexOf("depth"); if (di >= 0) depth = t[di + 1].toInt()
                val si = t.indexOf("score")
                if (t[si + 1] == "cp") { cp = t[si + 2].toInt(); mate = null }
                else if (t[si + 1] == "mate") { mate = t[si + 2].toInt(); cp = null }
            } else if (l.startsWith("bestmove")) {
                return Result(l.split(" ").getOrElse(1) { "" }, cp, mate, depth)
            }
        }
    }

    fun stop() { try { proc?.destroy() } catch (_: Exception) {}; proc = null }
}
