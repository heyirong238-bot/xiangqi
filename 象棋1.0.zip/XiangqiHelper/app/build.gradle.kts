plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.xqhelper"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.xqhelper"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += "arm64-v8a" }
    }
    // 让 libpikafish.so 被解压到磁盘，才能当可执行文件运行
    packaging { jniLibs { useLegacyPackaging = true } }
    androidResources { noCompress += "nnue" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
}
