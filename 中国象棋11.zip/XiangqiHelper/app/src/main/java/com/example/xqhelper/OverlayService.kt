package com.example.xqhelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var rec: Recognizer
    private val engine by lazy { Engine(this) }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var latest: Image? = null
    private val lock = Any()
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var panel: LinearLayout? = null
    private var info: TextView? = null
    private var arrow: ArrowView? = null
    private var calib: CalibView? = null
    private var redToMove = true
    private var started = false
    private var sw = 0; private var sh = 0

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (started || i == null) return START_NOT_STICKY
        started = true
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("xq", "象棋助手", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "xq").setContentTitle("象棋助手运行中")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        wm = getSystemService(WindowManager::class.java)
        rec = Recognizer(this)
        val data = i.getParcelableExtra<Intent>("data")!!
        projection = getSystemService(MediaProjectionManager::class.java)
            .getMediaProjection(i.getIntExtra("code", 0), data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, ui)
        setupCapture(); buildOverlay()
        return START_NOT_STICKY
    }

    // ---------- 截屏 ----------
    private fun setupCapture() {
        val b = wm.currentWindowMetrics.bounds; sw = b.width(); sh = b.height()
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            synchronized(lock) { latest?.close(); latest = img }
        }, ui)
        vd = projection!!.createVirtualDisplay("xq", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, ui)
    }

    private fun grab(): Bitmap? = synchronized(lock) {
        val img = latest ?: return null
        val p = img.planes[0]; p.buffer.rewind()
        val rw = p.rowStride / p.pixelStride
        val bmp = Bitmap.createBitmap(rw, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        if (rw == img.width) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }

    /** 先把悬浮窗和箭头藏起来，免得被截进画面里 */
    private fun capture(cb: (Bitmap?) -> Unit) {
        panel?.visibility = View.INVISIBLE; arrow?.clear()
        ui.postDelayed({ val b = grab(); panel?.visibility = View.VISIBLE; cb(b) }, 350)
    }

    // ---------- 悬浮窗界面 ----------
    private fun lp(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var fl = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (!touchable) fl = fl or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, fl,
            PixelFormat.TRANSLUCENT).apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
    }

    private fun buildOverlay() {
        val full = WindowManager.LayoutParams.MATCH_PARENT
        val wrap = WindowManager.LayoutParams.WRAP_CONTENT
        arrow = ArrowView(this); wm.addView(arrow, lp(full, full, false))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xE6202020.toInt()); setPadding(12, 12, 12, 12)
        }
        val handle = TextView(this).apply { text = "☰ 按住这里拖动"; setTextColor(Color.WHITE); textSize = 13f }
        val row = LinearLayout(this)
        fun btn(t: String, a: (Button) -> Unit) = Button(this).apply {
            text = t; textSize = 13f; minWidth = 0; minimumWidth = 0; setPadding(20, 0, 20, 0)
            setOnClickListener { a(this) }
        }.also { row.addView(it) }
        btn("分析") { analyze() }
        btn("走:红") { redToMove = !redToMove; it.text = if (redToMove) "走:红" else "走:黑" }
        btn("校准") { calibrate() }
        btn("学习") { learn() }
        btn("✕") { stopSelf() }
        info = TextView(this).apply {
            text = "先在开局画面点「校准」，再点「学习」"; setTextColor(Color.WHITE); textSize = 14f
            maxWidth = (sw * 0.8).toInt()
        }
        bar.addView(handle); bar.addView(row); bar.addView(info)

        val p = lp(wrap, wrap, true).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 200 }
        handle.setOnTouchListener(object : View.OnTouchListener {
            var lx = 0f; var ly = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        p.x += (e.rawX - lx).toInt(); p.y += (e.rawY - ly).toInt(); lx = e.rawX; ly = e.rawY
                        wm.updateViewLayout(bar, p)
                    }
                }
                return true
            }
        })
        wm.addView(bar, p); panel = bar
    }

    private fun say(t: String) { ui.post { info?.text = t } }

    // ---------- 功能 ----------
    private fun calibrate() {
        if (calib != null) return
        if (!rec.calibrated) {
            rec.x0 = sw * 0.08f; rec.x1 = sw * 0.92f; rec.y0 = sh * 0.25f; rec.y1 = rec.y0 + (rec.x1 - rec.x0) * 9f / 8f
        }
        panel?.visibility = View.INVISIBLE
        val v = CalibView(this, rec.x0, rec.y0, rec.x1, rec.y1, rec.flipped) { ok ->
            ui.post {
                val cv = calib ?: return@post
                if (ok) { rec.setCalib(cv.x0, cv.y0, cv.x1, cv.y1, cv.flipped); say("已校准。回到开局画面后点「学习」") }
                wm.removeView(cv); calib = null; panel?.visibility = View.VISIBLE
            }
        }
        calib = v; wm.addView(v, lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, true))
    }

    private fun learn() {
        if (!rec.calibrated) { say("请先点「校准」"); return }
        say("学习中…")
        capture { bmp ->
            if (bmp == null) { say("还没截到画面，请稍后再试"); return@capture }
            worker.execute { val n = rec.learn(bmp); say("已记住 $n 个格子的样子。现在可以点「分析」") }
        }
    }

    private fun analyze() {
        if (!rec.calibrated || !rec.learned) { say("请先在开局画面完成「校准」和「学习」"); return }
        say("识别中…")
        capture { bmp ->
            if (bmp == null) { say("还没截到画面，请稍后再试"); return@capture }
            worker.execute { try { doAnalyze(bmp) } catch (e: Exception) { say("出错：" + e.message) } }
        }
    }

    private fun doAnalyze(bmp: Bitmap) {
        val board = rec.recognize(bmp)
        val fen = Recognizer.toFen(board, redToMove) ?: return say("识别失败：没找到双方的将帅，请重新校准或学习")
        engine.start()?.let { return say(it) }
        say("皮卡鱼思考中…")
        val r = engine.analyze(fen, 1500)
        ui.post { show(board, r) }
    }

    private fun show(b: Array<CharArray>, r: Engine.Result) {
        val m = r.move
        if (m.length < 4 || m[0] !in 'a'..'i') { info?.text = "无着可走（已被将死或困毙）"; return }
        val fx = m[0] - 'a'; val fy = 9 - (m[1] - '0'); val tx = m[2] - 'a'; val ty = 9 - (m[3] - '0')
        val (ax, ay) = rec.toScreen(fx, fy); val (bx, by) = rec.toScreen(tx, ty)
        arrow?.set(ax, ay, bx, by)
        val sc = r.mate?.let { "${abs(it)}步杀" + if (it < 0) "（对己不利）" else "" } ?: (r.cp?.toString() ?: "?")
        info?.text = "推荐：${pieceName(b[fy][fx])} $m\n走棋方评分 $sc（深度${r.depth}，正数对走棋方有利）"
    }

    private fun pieceName(c: Char): String = when (c) {
        'K' -> "帅"; 'A' -> "仕"; 'B' -> "相"; 'N' -> "马"; 'R' -> "车"; 'C' -> "炮"; 'P' -> "兵"
        'k' -> "将"; 'a' -> "士"; 'b' -> "象"; 'n' -> "马"; 'r' -> "车"; 'c' -> "炮"; 'p' -> "卒"
        else -> "?"
    }

    override fun onDestroy() {
        if (started) {
            for (v in listOf<View?>(panel, arrow, calib)) try { if (v != null) wm.removeView(v) } catch (_: Exception) {}
            synchronized(lock) { latest?.close(); latest = null }
            vd?.release(); reader?.close(); projection?.stop(); engine.stop(); worker.shutdown()
        }
        super.onDestroy()
    }
}
