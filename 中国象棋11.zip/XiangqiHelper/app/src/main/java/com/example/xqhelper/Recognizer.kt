package com.example.xqhelper

import android.content.Context
import android.graphics.Bitmap
import java.io.*
import kotlin.math.abs

/**
 * 棋盘识别：校准棋盘左上/右下两个交叉点 → 在开局画面"学习"每种棋子的样子 →
 * 之后逐格与学到的样本做最近邻比对。坐标一律用屏幕像素。
 */
class Recognizer(ctx: Context) {
    companion object {
        const val N = 16
        val INIT = arrayOf(
            "rnbakabnr", ".........", ".c.....c.", "p.p.p.p.p", ".........",
            ".........", "P.P.P.P.P", ".C.....C.", ".........", "RNBAKABNR")

        /** 棋盘 → FEN；将帅不是各一个就返回 null */
        fun toFen(b: Array<CharArray>, redToMove: Boolean): String? {
            val flat = b.flatMap { it.toList() }
            if (flat.count { it == 'K' } != 1 || flat.count { it == 'k' } != 1) return null
            val rows = b.joinToString("/") { r ->
                val sb = StringBuilder(); var n = 0
                for (c in r) { if (c == '.') n++ else { if (n > 0) { sb.append(n); n = 0 }; sb.append(c) } }
                if (n > 0) sb.append(n)
                sb.toString()
            }
            return "$rows ${if (redToMove) "w" else "b"} - - 0 1"
        }
    }

    var x0 = 0f; var y0 = 0f; var x1 = 0f; var y1 = 0f
    var flipped = false          // 棋盘是否翻转（我执黑时红方在上）
    val calibrated: Boolean get() = x1 > x0 && y1 > y0
    val learned: Boolean get() = labels.isNotEmpty()

    private val labels = ArrayList<Char>()
    private val feats = ArrayList<ByteArray>()
    private val prefs = ctx.getSharedPreferences("cfg", 0)
    private val tf = File(ctx.filesDir, "templates.bin")

    init {
        x0 = prefs.getFloat("x0", 0f); y0 = prefs.getFloat("y0", 0f)
        x1 = prefs.getFloat("x1", 0f); y1 = prefs.getFloat("y1", 0f)
        flipped = prefs.getBoolean("flip", false)
        try { load() } catch (_: Exception) { labels.clear(); feats.clear() }
    }

    fun setCalib(a: Float, b: Float, c: Float, d: Float, f: Boolean) {
        x0 = a; y0 = b; x1 = c; y1 = d; flipped = f
        prefs.edit().putFloat("x0", a).putFloat("y0", b).putFloat("x1", c).putFloat("y1", d).putBoolean("flip", f).apply()
    }

    /** 逻辑坐标（x 0-8 自左，y 0-9 自上，黑在上）→ 屏幕像素 */
    fun toScreen(x: Int, y: Int): Pair<Float, Float> {
        val c = if (flipped) 8 - x else x
        val r = if (flipped) 9 - y else y
        return Pair(x0 + c * (x1 - x0) / 8f, y0 + r * (y1 - y0) / 9f)
    }

    private fun cell() = minOf((x1 - x0) / 8f, (y1 - y0) / 9f)

    private fun feat(bmp: Bitmap, cx: Float, cy: Float): ByteArray {
        val h = (cell() * 0.42f).toInt().coerceAtLeast(4)
        val l = (cx.toInt() - h).coerceIn(0, bmp.width - 2 * h)
        val t = (cy.toInt() - h).coerceIn(0, bmp.height - 2 * h)
        val sc = Bitmap.createScaledBitmap(Bitmap.createBitmap(bmp, l, t, 2 * h, 2 * h), N, N, true)
        val px = IntArray(N * N); sc.getPixels(px, 0, N, 0, 0, N, N)
        val f = ByteArray(N * N * 3)
        for (i in px.indices) {
            f[i * 3] = (px[i] shr 16).toByte(); f[i * 3 + 1] = (px[i] shr 8).toByte(); f[i * 3 + 2] = px[i].toByte()
        }
        return f
    }

    /** 在开局画面上学习：90 个格子（含空位）各存一份样本 */
    fun learn(bmp: Bitmap): Int {
        labels.clear(); feats.clear()
        for (y in 0..9) for (x in 0..8) {
            val (cx, cy) = toScreen(x, y)
            labels.add(INIT[y][x]); feats.add(feat(bmp, cx, cy))
        }
        save()
        return labels.size
    }

    fun recognize(bmp: Bitmap): Array<CharArray> = Array(10) { y ->
        CharArray(9) { x ->
            val (cx, cy) = toScreen(x, y)
            val f = feat(bmp, cx, cy)
            var best = '.'; var bd = Int.MAX_VALUE
            for (i in feats.indices) {
                val t = feats[i]; var d = 0
                for (k in f.indices) {
                    d += abs((f[k].toInt() and 255) - (t[k].toInt() and 255))
                    if (d >= bd) break
                }
                if (d < bd) { bd = d; best = labels[i] }
            }
            best
        }
    }

    private fun save() {
        DataOutputStream(BufferedOutputStream(FileOutputStream(tf))).use { o ->
            o.writeInt(labels.size)
            for (i in labels.indices) { o.writeChar(labels[i].code); o.write(feats[i]) }
        }
    }

    private fun load() {
        if (!tf.exists()) return
        DataInputStream(BufferedInputStream(FileInputStream(tf))).use { i ->
            val n = i.readInt()
            repeat(n) {
                labels.add(i.readChar())
                val b = ByteArray(N * N * 3); i.readFully(b); feats.add(b)
            }
        }
    }
}
